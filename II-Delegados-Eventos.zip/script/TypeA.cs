﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TypeA : MonoBehaviour
{
	//public Controller controller;
	
    // Start is called before the first frame update
    void Start()
    {
        Controller.controladorDeEscena.eventHandler += GivePower;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
	
	void GivePower(GameObject player)
	{
		Power power = player.GetComponent<Power>();
		power.powerValue += 1;
	}
}
